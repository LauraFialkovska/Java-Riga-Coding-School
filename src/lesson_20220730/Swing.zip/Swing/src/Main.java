import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main {
    public static void main(String[] args) throws Exception {

        Frame frame = new Frame();

        JFrame jFrame = frame.createFrame();
        JPanel jPanel = frame.createPanel(jFrame);

        /*
        // It causes conflict with frame panel (doesn't work)
        frame.setIcon(jFrame);
        frame.setBgColor(jFrame);
         */

        JLabel jLabel1 = new JLabel("Pink");
        JLabel jLabel2 = new JLabel("Blue");

        JButton jButton1 = new JButton("Change BG color to pink");
        JButton jButton2 = new JButton("Change BG color to blue");

        jPanel.add(jLabel1);
        jPanel.add(jButton1);
        jPanel.add(jLabel2);
        jPanel.add(jButton2);

        jButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jPanel.setBackground(Color.pink);
            }
        });

        jButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jPanel.setBackground(Color.blue);
            }
        });
    }
}