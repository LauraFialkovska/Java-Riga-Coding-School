import javax.swing.*;
import java.awt.*;

public class Frame {

    JFrame createFrame() {
        JFrame frame = new JFrame();

        frame.setVisible(true);
        frame.setSize(600, 600);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Hello World!");
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);

        return frame;
    }

    JPanel createPanel(JFrame frame) {
        JPanel panel = new JPanel();
        frame.add(panel);

        return panel;
    }

    void setIcon(JFrame frame) {
        ImageIcon icon = new ImageIcon("c:/auto/java/swing/src/images/golf-cart.png");
        frame.setIconImage(icon.getImage());
    }

    void setBgColor(JFrame frame) {
        frame.getContentPane().setBackground(new Color(226, 240, 250));
    }
}
